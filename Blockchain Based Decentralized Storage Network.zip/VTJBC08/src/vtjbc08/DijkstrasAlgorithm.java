package vtjbc08;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;


class DijkstrasAlgorithm {
 
    private static final int NO_PARENT = -1;
     public static List<PathModel> userdistances=new ArrayList();
     public static List<PathModel> userdistances1=new ArrayList();
 
    // Function that implements Dijkstra's
    // single source shortest path
    // algorithm for a graph represented 
    // using adjacency matrix
    // representation
    private static List<PathModel> dijkstra(int[][] adjacencyMatrix,
                                        int startVertex)
    {
        int nVertices = adjacencyMatrix[0].length;
        
        
        
       
 
        // shortestDistances[i] will hold the
        // shortest distance from src to i
        int[] shortestDistances = new int[nVertices];
 
        // added[i] will true if vertex i is
        // included / in shortest path tree
        // or shortest distance from src to 
        // i is finalized
        boolean[] added = new boolean[nVertices];
 
        // Initialize all distances as 
        // INFINITE and added[] as false
        for (int vertexIndex = 0; vertexIndex < nVertices; 
                                            vertexIndex++)
        {
            shortestDistances[vertexIndex] = Integer.MAX_VALUE;
            added[vertexIndex] = false;
        }
         
        // Distance of source vertex from
        // itself is always 0
        shortestDistances[startVertex] = 0;
 
        // Parent array to store shortest
        // path tree
        int[] parents = new int[nVertices];
 
        // The starting vertex does not 
        // have a parent
        parents[startVertex] = NO_PARENT;
 
        // Find shortest path for all 
        // vertices
        for (int i = 1; i < nVertices; i++)
        {
 
            // Pick the minimum distance vertex
            // from the set of vertices not yet
            // processed. nearestVertex is 
            // always equal to startNode in 
            // first iteration.
            int nearestVertex = -1;
            int shortestDistance = Integer.MAX_VALUE;
            for (int vertexIndex = 0;
                     vertexIndex < nVertices; 
                     vertexIndex++)
            {
                if (!added[vertexIndex] &&
                    shortestDistances[vertexIndex] < 
                    shortestDistance) 
                {
                    nearestVertex = vertexIndex;
                    shortestDistance = shortestDistances[vertexIndex];
                }
            }
 
            // Mark the picked vertex as
            // processed
            added[nearestVertex] = true;
 
            // Update dist value of the
            // adjacent vertices of the
            // picked vertex.
            for (int vertexIndex = 0;
                     vertexIndex < nVertices; 
                     vertexIndex++) 
            {
                int edgeDistance = adjacencyMatrix[nearestVertex][vertexIndex];
                 
                if (edgeDistance > 0
                    && ((shortestDistance + edgeDistance) < 
                        shortestDistances[vertexIndex])) 
                {
                    parents[vertexIndex] = nearestVertex;
                    shortestDistances[vertexIndex] = shortestDistance + 
                                                       edgeDistance;
                }
            }
        }
 
        printSolution(startVertex, shortestDistances, parents);
        
        return userdistances1;
    }
 
    // A utility function to print 
    // the constructed distances
    // array and shortest paths
    private static void printSolution(int startVertex,
                                      int[] distances,
                                      int[] parents)
    {
        int nVertices = distances.length;
        System.out.print("Vertex\t Distance\tPath");
          
        for (int vertexIndex = 0; 
                 vertexIndex < nVertices; 
                 vertexIndex++) 
        {
            if (vertexIndex != startVertex) 
            {
                PathModel path=null;
               path=new PathModel();
               StringBuffer sb=new StringBuffer();
                System.out.print("\n" + startVertex + " -> ");
                System.out.print(vertexIndex + " \t\t ");
                System.out.print("distance"+distances[vertexIndex] + "\t\t");
                int distance = distances[vertexIndex];
                 path.setDistances(distance);
                printPath(vertexIndex, parents,path,sb);
                userdistances.add(path);
                
            }
            
        }
        
        System.out.println(userdistances.toString());
        
        for(PathModel pm: userdistances){
            PathModel pm1=new PathModel();
            pm1.setDistances(pm.getDistances());
            pm1.setPaths(pm.getPaths().substring(1));
            userdistances1.add(pm1);
            
        }
         System.out.println(userdistances1.toString());
    }
 
    // Function to print shortest path
    // from source to currentVertex
    // using parents array
    private static void printPath(int currentVertex,
                                  int[] parents,PathModel pm,StringBuffer sb)
    {
         
        // Base case : Source node has
        // been processed
        if (currentVertex == NO_PARENT)
        {
            return;
        }
        printPath(parents[currentVertex], parents,pm,sb);
        sb.append(","+currentVertex);
        pm.setPaths(sb.toString());
        System.out.print(currentVertex + " ");
    }
 
        // Driver Code
    public static void main(String[] args)
    {
        Random r=new Random();
        int a,b,c,d,e,f,g,h,i,j,k,l,m;
         a=r.nextInt(12);b=r.nextInt(12);c=r.nextInt(12);
        int[][] adjacencyMatrix = { { 0, a, 0, 12, 12, 0, 0, b, 0 },
                                    { 4, 0, 8, 12, 0, 0, 0, 11, 0 },
                                    { 12, 8, 0, 7, 0, 4, 0, 0, 2 },
                                    { 12, 12, 7, 0, 9, 14, 0, 0, 0 },
                                    { 12, 10, 10, 9, 0, 10, 0, 0, 0 },
                                    { 12, 0, 4, 0, 10, 0, 2, 0, 0 },
                                    { 0, 0, 0, c, 0, 2, 0, 1, 6 },
                                    { 8, 11, 0, 0, 0, 0, 1, 0, 7 },
                                    { 0, 0, 2, 0, 0, 0, 6, 7, 0 } };
      List<PathModel> finalList=  dijkstra(adjacencyMatrix, 0);
      System.out.println("the final result isss"+finalList);
    }
    
    
    public static List<PathModel> getThePaths(){
        Random r=new Random();
        int a,b,c,d,e,f,g,h,i,j,k,l,m;
         a=r.nextInt(12);b=r.nextInt(12);c=r.nextInt(12);
        int[][] adjacencyMatrix = { { 1, a, 2, 12, 12, 1, 1, b, 1 },
                                    { 4, 1, 8, 12, 1, 1, 1, 11, 1 },
                                    { 12, 8, 1, 7, 1, 4, 1, 1, 2 },
                                    { 12, 12, 7, 1, 9, 14, 1, 1, 1 },
                                    { 12, 10, 10, 9, 1, 10, 1, 1, 1 },
                                    { 12, 1, 4, 1, 10, 1, 2, 1, 1 },
                                    { 1, 1, 1, c, 1, 2, 1, 1, 6 },
                                    { 8, 11, 1, 1, 1, 1, 1, 1, 7 },
                                    { 0, 0, 2, 0, 0, 0, 6, 7, 1 } };
      return dijkstra(adjacencyMatrix, 1);
    }
}
