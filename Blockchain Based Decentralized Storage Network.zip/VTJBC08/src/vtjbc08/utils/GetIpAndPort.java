/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vtjbc08.utils;

import java.net.Inet4Address;
import java.util.Random;
import models.IpAndPort;

/**
 *
 * @author shyam
 */


public class GetIpAndPort {
    
   static String client_ip;
   static int client_port;
  
    public static IpAndPort getipAndPort(){
           IpAndPort ipAndPort=null;
        try{
    Inet4Address ipadd = (Inet4Address) Inet4Address.getLocalHost();
			client_ip=ipadd.getHostAddress();
			Random r=new Random();
                        client_port=r.nextInt(1000);
                ipAndPort  =new IpAndPort();
                   ipAndPort.setIp(client_ip);ipAndPort.setPort(client_port);
        }catch(Exception e){
            e.printStackTrace();
        }
                    return ipAndPort;
    }
}
