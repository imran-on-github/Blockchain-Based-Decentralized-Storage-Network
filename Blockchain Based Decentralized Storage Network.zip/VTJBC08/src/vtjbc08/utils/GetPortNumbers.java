/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vtjbc08.utils;

/**
 *
 * @author shyam
 */
public class GetPortNumbers {
    
    public static int getPort(int port){
        
        if(port==1){
            return 10001;
        }else if(port==2){
            return 10002;
        }
        else if(port==3){
            return 10003;
        }
        else if(port==4){
            return 10004;
        }
        else if(port==5){
            return 10005;
        }
        else if(port==6){
            return 10006;
        }else if(port==7){
            return 10007;
        }else if(port==8){
            return 10008;
        }else if(port==9){
            return 10009;
        }else if(port==10){
            return 10010;
        }else if(port==0){
            return 10010;
        }
        else{
            return 10010;
        }
        
    }
    
}
