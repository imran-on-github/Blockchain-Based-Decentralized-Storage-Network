/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vtjbc08.utils;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
 *
 * @author shyam
 */
public class ClientInputRead {
    
    
    public static FileDetails clientMsgRead(Socket s){
        
        FileDetails fd=null;
        try{
           InputStream in=s.getInputStream();
                            ObjectInputStream out=new ObjectInputStream(in);
                           // System.out.println("output stream"+out.readObject())
                             fd=(FileDetails) out.readObject();
                            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return fd;
    }
    
}
