/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vtjbc08.utils;

import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author shyam
 */
public class ClientConnect {
    
    public static Socket clientConnect(String ip, int port,FileDetails fd){
        Socket socket=null;
        try{
                socket=new Socket("localhost",port);
                 ObjectOutputStream os=new ObjectOutputStream(socket.getOutputStream());
	         os.writeObject(fd);
                 
        }catch(Exception e){
            e.printStackTrace();
        }
        
     return socket;   
    }
    
}
